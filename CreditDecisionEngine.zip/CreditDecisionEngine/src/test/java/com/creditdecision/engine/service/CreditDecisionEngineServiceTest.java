package com.creditdecision.engine.service;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.creditdecision.engine.pojo.CreditRequest;
import com.creditdecision.engine.pojo.CreditScore;
import com.creditdecision.engine.pojo.Response;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {  CreditDecisionEngineService.class,RestTemplate.class})
class CreditDecisionEngineServiceTest {
	@Autowired
	CreditDecisionEngineService creditDecisionEngineService;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@Mock
	RestTemplate restTemplate;
	
	@Mock
	Response res;
	
	@Test
	void testGetcreditScore() {
		CreditScore cs = creditScore();
		Mockito.when(restTemplate.getForObject("http://testUrl/ssn01", CreditScore.class)).thenReturn(cs);
		Assert.assertEquals("ssn01", cs.getSsnNumber());
		Assert.assertEquals("700", creditScore().getCreditScore());
		//Mockito.when(creditScore().getLoanAmount()>700).thenReturn(new Response());
	}
	public CreditRequest creditReq() {

		CreditRequest cr = new CreditRequest();
		cr.setSsnNumber("ssn01");
		cr.setLoanAmount(1234454523);
		cr.setCurrentAnnualIncome(2342342);
		return cr;
	}

	public CreditScore creditScore() {
		CreditScore cs = new CreditScore();
		cs.setSsnNumber("ssn01");
		cs.setCreditScore("700");
		return cs;

	}

}
