package com.creditdecision.engine.controller;

import static org.mockito.Mockito.when;

import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.creditdecision.engine.pojo.CreditRequest;
import com.creditdecision.engine.pojo.CreditScore;
import com.creditdecision.engine.pojo.Response;
import com.creditdecision.engine.service.CreditDecisionEngineService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CreditDecisionEngineController.class, CreditDecisionEngineService.class,
		RestTemplate.class })
@WebAppConfiguration
class CreditDecisionEngineControllerTest {

	@Autowired
	CreditDecisionEngineController creditDecisionEngineController;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@InjectMocks
	CreditDecisionEngineService creditDecisionEngineService;

	@Mock
	RestTemplate restTemplate;
	
	@Autowired
	SessionFactory sessionFactory;

	@Value("${url.name}")
	String urlName;

	@Test
	void testGetCreditRequest() {
		creditDecisionEngineController.getCreditRequest(creditReq());

		CreditRequest crereq = creditReq();

		Response crescore = new Response();
		Mockito.when(creditDecisionEngineService.getcreditScore(crereq)).thenReturn(crescore);
		Assert.assertEquals("ssn01", crescore.getSsnNumber());

		Mockito.when(restTemplate.getForEntity("http://localhost:8081/getCreditScore", CreditScore.class))
				.thenReturn(new ResponseEntity(crescore, HttpStatus.OK));
		when(restTemplate.getForObject(urlName, CreditScore.class)).thenReturn(new CreditScore());
		Assert.assertNotNull(crescore);
	}

	// Negative test scenario ResourceAccessException, etc
	@Test
	void testGetCreditRequestNegative() {
		creditDecisionEngineController.getCreditRequest(creditReq());

		CreditRequest crereq = creditReq();

		Response crescore = new Response();
		Mockito.when(creditDecisionEngineService.getcreditScore(crereq)).thenReturn(crescore);
		Assert.assertEquals("ssn01", crescore.getSsnNumber());
		Assert.assertEquals(ResourceAccessException.class, creditDecisionEngineService.getcreditScore(crereq));
		Mockito.when(restTemplate.getForEntity("http://localhost:8081/getCreditScore", CreditScore.class))
				.thenReturn(new ResponseEntity(crescore, HttpStatus.OK));
		when(restTemplate.getForObject(urlName, CreditScore.class)).thenReturn(new CreditScore());
		Assert.assertNotNull(crescore);
	}

	public CreditRequest creditReq() {

		CreditRequest cr = new CreditRequest();
		cr.setSsnNumber("ssn01");
		cr.setLoanAmount(1234454523);
		cr.setCurrentAnnualIncome(2342342);
		return cr;
	}

	public CreditScore creditScore() {
		CreditScore cs = new CreditScore();

		cs.setCreditScore("700");
		return cs;

	}
}
