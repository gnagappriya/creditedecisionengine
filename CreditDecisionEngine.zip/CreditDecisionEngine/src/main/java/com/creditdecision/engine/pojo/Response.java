package com.creditdecision.engine.pojo;

public class Response {
	private String ssnNumber;
	private Integer sanctionAmount;
	private String message;
	
	/**
	 * @return the ssnNumber
	 */
	public String getSsnNumber() {
		return ssnNumber;
	}
	/**
	 * @param ssnNumber the ssnNumber to set
	 */
	public void setSsnNumber(String ssnNumber) {
		this.ssnNumber = ssnNumber;
	}
	/**
	 * @return the sanctionAmount
	 */
	public Integer getSanctionAmount() {
		return sanctionAmount;
	}
	/**
	 * @param sanctionAmount the sanctionAmount to set
	 */
	public void setSanctionAmount(Integer sanctionAmount) {
		this.sanctionAmount = sanctionAmount;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
