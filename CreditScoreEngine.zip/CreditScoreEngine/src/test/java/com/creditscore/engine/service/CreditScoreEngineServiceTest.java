package com.creditscore.engine.service;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.creditscore.engine.controller.CreditScoreEngineController;
import com.creditscore.engine.pojo.CreditRequest;
import com.creditscore.engine.pojo.CreditScore;
import com.creditscore.engine.repository.CreditScoreEngineRepository;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CreditScoreEngineController.class, CreditScoreEngineService.class,CreditScoreEngineRepository.class,
		RestTemplate.class })
@WebAppConfiguration
class CreditScoreEngineServiceTest {
	
	@Autowired
	CreditScoreEngineRepository creditScoreEngineRepository;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testGetcreditScore() {
		CreditScore creditScore = creditScoreEngineRepository.getCreditScore(creditReq() );
		Assert.assertEquals(700, creditScore.getCreditScore());
	}
	public CreditRequest creditReq() {

		CreditRequest cr = new CreditRequest();
		cr.setSsnNumber("ssn01");
		cr.setLoanAmount(1234454523);
		cr.setCurrentAnnualIncome(2342342);
		return cr;
	}

	public CreditScore creditScore() {
		CreditScore cs = new CreditScore();
		cs.setSsnNumber("ssn01");
		cs.setCreditScore("700");
		return cs;

	}
}
