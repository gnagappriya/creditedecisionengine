package com.creditscore.engine.repository;



import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.creditscore.engine.controller.CreditScoreEngineController;
import com.creditscore.engine.pojo.CreditRequest;
import com.creditscore.engine.pojo.CreditScore;
import com.creditscore.engine.service.CreditScoreEngineService;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CreditScoreEngineController.class, CreditScoreEngineService.class,CreditScoreEngineRepository.class,
		RestTemplate.class })
@WebAppConfiguration
class CreditScoreEngineRepositoryTest {

	 @Mock
	 private SessionFactory sessionFactory;
	 
	 @Mock
	 Query query;
	 
	@Test
	void testGetCreditScore() {
		
		Mockito.when(sessionFactory.getCurrentSession().createQuery("select * from credit_score where ssn_number = :ssn_number")).thenReturn(query);
		query.setParameter("ssn_number", "ssn01");
		Mockito.when(query.getResultList().get(0)).thenReturn(creditScore());
		Assert.assertEquals("ssn01", creditScore().getSsnNumber());
		Assert.assertEquals(700, creditScore().getCreditScore());
	}
	public CreditRequest creditReq() {

		CreditRequest cr = new CreditRequest();
		cr.setSsnNumber("ssn01");
		cr.setLoanAmount(1234454523);
		cr.setCurrentAnnualIncome(2342342);
		return cr;
	}

	public CreditScore creditScore() {
		CreditScore cs = new CreditScore();
		cs.setSsnNumber("ssn01");
		cs.setCreditScore("700");
		return cs;

	}
}
