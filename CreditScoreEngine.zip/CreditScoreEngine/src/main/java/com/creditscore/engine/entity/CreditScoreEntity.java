package com.creditscore.engine.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="CREDIT_SCORE")
public class CreditScoreEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	
	@Column(name="SSN_NUMBER")
	String ssnNumber;
	
	@Column(name="CREDIT_SCORE")
	String creditScore;
	
	@Column(name="CREDIT_DATE")
	private Date creditDate;
	
	
	public CreditScoreEntity() {
		
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the ssnNumber
	 */
	public String getSsnNumber() {
		return ssnNumber;
	}

	/**
	 * @param ssnNumber the ssnNumber to set
	 */
	public void setSsnNumber(String ssnNumber) {
		this.ssnNumber = ssnNumber;
	}

	/**
	 * @return the creditScore
	 */
	public String getCreditScore() {
		return creditScore;
	}

	/**
	 * @param creditScore the creditScore to set
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}
	/**
	 * @return the creditDate
	 */
	public Date getCreditDate() {
		return creditDate;
	}
	/**
	 * @param creditDate the creditDate to set
	 */
	public void setCreditDate(Date creditDate) {
		this.creditDate = creditDate;
	}

	
	
	
}
