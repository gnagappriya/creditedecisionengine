package com.creditscore.engine.pojo;

import java.util.Date;

public class CreditScore {
	private String ssnNumber;
	private String creditScore;
	private Date creditDate;
	private String message;
	/**
	 * @return the creditScore
	 */
	public String getCreditScore() {
		return creditScore;
	}
	/**
	 * @param creditScore the creditScore to set
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}
	
	/**
	 * @return the creditDate
	 */
	public Date getCreditDate() {
		return creditDate;
	}
	/**
	 * @param creditDate the creditDate to set
	 */
	public void setCreditDate(Date creditDate) {
		this.creditDate = creditDate;
	}
	/**
	 * @return the ssnNumber
	 */
	public String getSsnNumber() {
		return ssnNumber;
	}
	/**
	 * @param ssnNumber the ssnNumber to set
	 */
	public void setSsnNumber(String ssnNumber) {
		this.ssnNumber = ssnNumber;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
